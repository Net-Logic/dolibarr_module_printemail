
## Unreleased (2023-08-24)

#### :rocket: Enhancement
* [#6](https://github.com/Net-Logic/dolibarr_module_printemail/pull/6) translations ([@frederic34](https://github.com/frederic34))

#### Committers: 1
- Frédéric FRANCE ([@frederic34](https://github.com/frederic34))


## v1.0.0 (2023-08-24)

#### :bug: Bug Fix
* [#4](https://github.com/Net-Logic/dolibarr_module_printemail/pull/4) fix old module no longer working ([@frederic34](https://github.com/frederic34))

#### Committers: 1
- Frédéric FRANCE ([@frederic34](https://github.com/frederic34))
