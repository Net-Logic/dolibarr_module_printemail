# dolibarr_printemail

Un module Dolibarr pour imprimer vers une adresse email
